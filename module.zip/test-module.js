const { MessageCommandBuilder, SlashCommandBuilder } = require('reciple');

module.exports = {
    versions: ['^5.1.1'],
    commands: [
        new MessageCommandBuilder()
            .setName('ping')
            .setDescription('Pong!')
            .setExecute(async command => command.message.reply('Pong!')),
        new SlashCommandBuilder()
            .setName('ping')
            .setDescription('Pong!')
            .setExecute(async command => command.interaction.reply('Pong!'))
    ],
    onStart(client) {
        client.logger.info('Started!');
        return true;
    }
};